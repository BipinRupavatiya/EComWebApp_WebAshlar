﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc;

namespace EComWebApp.Filter
{
	public class ExceptionFilter : IExceptionFilter
	{
		private readonly IModelMetadataProvider _modelMetadataProvider;

		public ExceptionFilter(IModelMetadataProvider modelMetadataProvider)
		{
			_modelMetadataProvider = modelMetadataProvider;
		}

		public void OnException(ExceptionContext context)
		{
			var result = new ViewResult { ViewName = "CustomError" };
			result.ViewData = new ViewDataDictionary(_modelMetadataProvider, context.ModelState);
			result.ViewData.Add("Exception", context.Exception);

			// Here we can pass additional detailed data via ViewData
			context.ExceptionHandled = true; // mark exception as handled
			context.Result = result;
		}
	}
}
