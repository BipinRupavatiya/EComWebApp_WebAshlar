﻿using System.ComponentModel.DataAnnotations;

namespace EComWebApp.Models
{
    public class Order
    {
        [Display(Name="Order ID")]
        public int ID { get; set; }
        public List<OrderItem> OrderItems { get; set; }

        [Display(Name = "Customer ID")]
        [MaxLength(50)]
        public string UserID { get; set; }

		[Display(Name = "Customer Name")]
		[MaxLength(200)]
		public string UserName { get; set; }

		[Display(Name = "Shipping Method")]
        [MaxLength(50)]
        public string Shipping { get; set; }

        [Display(Name = "Address ID")]
        public int AddressID { get; set; }

        public Address Address { get; set; }

        [Display(Name = "Order Date")]
        public DateTime OrderDate { get; set; }

        [Display(Name = "Total Item Quantity")]
        public int TotalItemQty { get; set; }

        [Display(Name = "Discount Name")]
        [MaxLength(50)]
        public string DiscountName { get; set; }

        [Display(Name = "Discount Percent")]
        public decimal DiscountPercent { get; set; }

        [Display(Name = "Discount Amount")]
        public decimal DiscountAmt { get; set; }

        public decimal Subtotal { get; set; }

        public decimal Total { get; set; }
    }
}
