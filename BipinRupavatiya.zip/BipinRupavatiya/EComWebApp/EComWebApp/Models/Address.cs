﻿using System.ComponentModel.DataAnnotations;

namespace EComWebApp.Models
{
    public class Address
    {
        public int ID { get; set; }

        [Required]
        [Display(Name = "First Name")]
        [MaxLength(100)]
        public string FirstName { get; set; }

        [Required]
        [Display(Name ="Last Name")]
        [MaxLength(100)]
        public string LastName { get; set; }

        [Required]
        [MaxLength(200)]
        public string Street { get; set; }

        [Display(Name ="Street (cont.)")]
        [MaxLength(200)]
        public string Street2 { get; set; }

        [Required]
        [MaxLength(30)]
        public string City { get; set; }

        [Required]
        [MaxLength(20)]
        public string State { get; set; }

        [Required]
        [MaxLength(20)]
        public string Country { get; set; }

        [Required]
        public int Zip { get; set; }

        [Required]
        public string UserID { get; set; }
    }
}