﻿using System.Net;
using EComWebApp.Data;
using Microsoft.EntityFrameworkCore;

namespace EComWebApp.Models.Interfaces
{
    public class CartRepository : ICartRepository
    {
        private readonly DBContext _context;
        public CartRepository(DBContext context)
        {
            _context = context;
        }
        public async Task<HttpStatusCode> CreateCart(Cart Cart)
        {
            try
            {
                _context.Add(Cart);
                await _context.SaveChangesAsync();
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }

            return HttpStatusCode.Created;
        }
        public async Task<HttpStatusCode> AddProductToCart(string email, Product product)
        {
            try
            {
                Cart datCart = GetUserCartByEmail(email).Result;
                CartItem datcartItem = datCart.cartItems.FirstOrDefault(i => i.ProductID == product.ID);
                if (datcartItem != null)
                {
                    datcartItem.Quantity++;
                    await UpdateCart(email, datcartItem);
                    return HttpStatusCode.Created;
                }
                datcartItem = new CartItem
                {
                    ProductID = product.ID,
                    ProductName = product.Name,
                    CustomerEmail = email,
                    Quantity = 1,
                    UnitPrice = product.Price,
                    ImgUrl = product.ImgUrl
                };
                await _context.AddAsync(datcartItem);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
        public async Task<HttpStatusCode> DeleteProductFromCart(CartItem cartItem)
        {
            try
            {
                _context.Remove(cartItem);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
        public async Task<HttpStatusCode> ClearOutCart(List<CartItem> cartItems)
        {
            try
            {
                _context.RemoveRange(cartItems);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
        public async Task<Cart> GetUserCartByEmail(string email)
        {
            var prodInts = _context.CartItems.Where(d => d.CustomerEmail == email).Select(p => p.ProductID);
            List<CartItem> demItems = _context.CartItems.Where(d => d.CustomerEmail == email).ToList();
            Cart datCart = await _context.Carts.FirstOrDefaultAsync(b => b.CustomerEmail == email);
            if (datCart != null)
                datCart.cartItems = demItems;
            return datCart;
        }
        public async Task<HttpStatusCode> UpdateCart(string email, CartItem cartItem)
        {
            try
            {
                _context.Update(cartItem);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }

            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
    }
}
