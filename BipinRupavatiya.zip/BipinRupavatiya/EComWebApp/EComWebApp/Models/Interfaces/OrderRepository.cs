﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using EComWebApp.Data;
using System.Net;

namespace EComWebApp.Models.Interfaces
{
    public class OrderRepository : IOrderRepository
    {
        private readonly DBContext _context;
        public OrderRepository(DBContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
        }
        public async Task<Order> GetOrderByIDAsync(int id)
        {
            List<OrderItem> demItems = await _context.OrderItems.Where(i => i.OrderID == id).ToListAsync();
            Order datOrder = await _context.Orders.FirstOrDefaultAsync(o => o.ID == id);

            if (datOrder != null)
                datOrder.OrderItems = demItems;

            return datOrder;
        }
        public async Task<HttpStatusCode> AddOrderAsync(Order order)
        {
            try
            {
                _context.Add(order);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
        public async Task<HttpStatusCode> AddOrderItemToOrderAsync(OrderItem orderItem)
        {
            try
            {
                _context.OrderItems.Add(orderItem);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
        public async Task<HttpStatusCode> UpdateOrderAsync(Order order)
        {
            try
            {
                _context.Orders.Update(order);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
        public async Task<HttpStatusCode> DeleteOrderAsync(int id)
        {

            try
            {
                Order orderToRemove = await _context.Orders.FirstOrDefaultAsync(o => o.ID == id);
                List<OrderItem> orderItemsToRemove = await _context.OrderItems.Where(i => i.OrderID == orderToRemove.ID).ToListAsync();

                _context.RemoveRange(orderItemsToRemove);
                _context.Remove(orderToRemove);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
        public async Task<HttpStatusCode> CreateAddress(Address address)
        {
            try
            {
                _context.Add(address);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch
            {
                return HttpStatusCode.BadRequest;
            }
        }
        public async Task<List<Order>> GetRecentOrdersAsync(int n, int? orderId)
        {
            if (orderId == null || orderId == 0)
            {
				return await _context.Orders.OrderByDescending(d => d.ID).Skip(Math.Max(0, _context.Orders.Count() - n)).ToListAsync();
			}
            else
            {
				return await _context.Orders.Where(o => o.ID == orderId).OrderByDescending(d => d.ID).Skip(Math.Max(0, _context.Orders.Count() - n)).ToListAsync();
			}
		}
        public async Task<List<Order>> GetRecentOrdersAsync(int n, string userID)
        {
            var orderQuery = _context.Orders.Where(o => o.UserID == userID);
            int orderCount = orderQuery.Count();
            return await orderQuery.Skip(Math.Max(0, orderCount - n)).ToListAsync();
        }
        public async Task<Address> GetAddressByIDAsync(int id)
        {
            return await _context.Addresses.FirstOrDefaultAsync(a => a.ID == id);
        }
        public async Task<List<OrderItem>> GetOrderItemsByOrderIDAsync(int id)
        {
            return await _context.OrderItems.Where(i => i.OrderID == id).ToListAsync();
        }
        public async Task<List<Order>> GetRecentOrdersByUserAsync(int n, string userId)
        {
            return await _context.Orders.Where(x => x.UserID == userId).OrderByDescending(d => d.ID).Skip(Math.Max(0, _context.Orders.Count() - n)).ToListAsync();
        }
    }
}