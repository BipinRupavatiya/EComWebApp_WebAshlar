﻿using System.Net;

namespace EComWebApp.Models
{
    public interface ICartRepository
    {
        Task<HttpStatusCode> CreateCart(Cart Cart);

        Task<HttpStatusCode> AddProductToCart(string email, Product product);

        Task<Cart> GetUserCartByEmail(string email);

        Task<HttpStatusCode> UpdateCart(string email, CartItem cartItem);

        Task<HttpStatusCode> DeleteProductFromCart(CartItem cartItem);

        Task<HttpStatusCode> ClearOutCart(List<CartItem> cartItems);
    }
}
