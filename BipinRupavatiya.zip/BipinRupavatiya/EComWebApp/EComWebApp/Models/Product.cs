﻿using System.ComponentModel.DataAnnotations;

namespace EComWebApp.Models
{
    public class Product
    {
        public int ID { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [Required]
        [MaxLength(100)]
        public string SKU { get; set; }

        [Required]
        public decimal Price { get; set; }
        [MaxLength(300)]
        public string Description { get; set; }

        [Display(Name = "Image")]
        [MaxLength(100)]
        public string ImgUrl { get; set; }
    }
}