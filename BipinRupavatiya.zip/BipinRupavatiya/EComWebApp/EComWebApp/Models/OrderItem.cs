﻿using System.ComponentModel.DataAnnotations;

namespace EComWebApp.Models
{
    public class OrderItem
    {
        public int ID { get; set; }
        public int OrderID { get; set; }
        public int ProductID { get; set; }
        [MaxLength(50)]
        public string UserID { get; set; }
        [MaxLength(100)]
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        [MaxLength(100)]
        public string ImgUrl { get; set; }
        public decimal UnitPrice { get; set; }
    }
}