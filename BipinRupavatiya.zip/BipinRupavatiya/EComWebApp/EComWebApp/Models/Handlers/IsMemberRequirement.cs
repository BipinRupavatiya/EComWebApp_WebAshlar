﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EComWebApp.Models.Handlers
{
    public class IsMemberRequirement : IAuthorizationRequirement
    {
        public string Email { get; set; }

        public IsMemberRequirement(string email)
        {
            Email = email;
        }
    }
}
