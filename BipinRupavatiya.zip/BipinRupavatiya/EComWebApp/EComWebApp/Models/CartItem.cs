﻿using System.ComponentModel.DataAnnotations;

namespace EComWebApp.Models
{
    public class CartItem
    {
        public int ID { get; set; }
        public int ProductID { get; set; }
        [MaxLength(100)]
        public string ProductName { get; set; }
        [MaxLength(100)]
        public string CustomerEmail { get; set; }
        public int Quantity { get; set; }
        public string ImgUrl { get; set; }
        public decimal UnitPrice { get; set; }
    }
}