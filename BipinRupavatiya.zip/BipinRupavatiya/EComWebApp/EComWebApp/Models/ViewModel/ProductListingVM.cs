﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EComWebApp.Models.ViewModel
{
    public class ProductListingVM
    {
        public List<Product> Products { get; set; }
    }
}
