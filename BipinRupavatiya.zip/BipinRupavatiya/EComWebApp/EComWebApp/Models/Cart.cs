﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EComWebApp.Models
{
    public class Cart
    {
        public int ID { get; set; }
        [MaxLength(100)]
        public string CustomerEmail { get; set; }
        public List<CartItem> cartItems { get; set; }

        public Cart()
        {
            cartItems = new List<CartItem>();
        }
    }
}