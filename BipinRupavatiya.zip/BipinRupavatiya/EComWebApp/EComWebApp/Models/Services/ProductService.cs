﻿using System.Net;

namespace EComWebApp.Models.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _iProductRepository;
        public ProductService(IProductRepository iProductRepository)
        {
            _iProductRepository = iProductRepository;
        }
        public Task<HttpStatusCode> CreateProduct(Product product)
        {
            return _iProductRepository.CreateProduct(product);
        }

        public Task<HttpStatusCode> DeleteProduct(int id)
        {
            return _iProductRepository.DeleteProduct(id);
        }

        public Task<Product> GetProductById(int? id)
        {
            return _iProductRepository.GetProductById(id);
        }

        public Task<List<Product>> GetProducts()
        {
            return _iProductRepository.GetProducts();
        }

        public Task<Product> UpdateProduct(int id, Product product)
        {
            return _iProductRepository.UpdateProduct(id, product);
        }
    }
}
