﻿using System.Net;

namespace EComWebApp.Models.Services
{
    public class CartService : ICartService
    {
        private readonly ICartRepository _iCartRepository;
        public CartService(ICartRepository iCartRepository)
        {
            _iCartRepository = iCartRepository;
        }

        public Task<HttpStatusCode> AddProductToCart(string email, Product product)
        {
            return _iCartRepository.AddProductToCart(email, product);
        }

        public Task<HttpStatusCode> ClearOutCart(List<CartItem> cartItems)
        {
            return _iCartRepository.ClearOutCart(cartItems);
        }

        public Task<HttpStatusCode> CreateCart(Cart Cart)
        {
            return _iCartRepository.CreateCart(Cart);
        }

        public Task<HttpStatusCode> DeleteProductFromCart(CartItem cartItem)
        {
            return _iCartRepository.DeleteProductFromCart(cartItem);
        }

        public Task<Cart> GetUserCartByEmail(string email)
        {
            return _iCartRepository.GetUserCartByEmail(email);
        }

        public Task<HttpStatusCode> UpdateCart(string email, CartItem cartItem)
        {
            return _iCartRepository.UpdateCart(email, cartItem);
        }
    }
}
