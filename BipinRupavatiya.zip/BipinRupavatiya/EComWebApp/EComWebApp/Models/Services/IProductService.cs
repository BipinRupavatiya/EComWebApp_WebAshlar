﻿using System.Net;

namespace EComWebApp.Models
{
    public interface IProductService
    {
        Task<HttpStatusCode> CreateProduct(Product product);

        Task<Product> GetProductById(int? id);

        Task<List<Product>> GetProducts();

        Task<Product> UpdateProduct(int id, Product product);

        Task<HttpStatusCode> DeleteProduct(int id);
    }
}
