﻿using System.Net;

namespace EComWebApp.Models.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _iOrderRepository;
        public OrderService(IOrderRepository iOrderRepository)
        {
            _iOrderRepository = iOrderRepository;
        }
        public Task<HttpStatusCode> AddOrderAsync(Order order)
        {
            return _iOrderRepository.AddOrderAsync(order);
        }

        public Task<HttpStatusCode> AddOrderItemToOrderAsync(OrderItem orderItem)
        {
            return _iOrderRepository.AddOrderItemToOrderAsync(orderItem);
        }

        public Task<HttpStatusCode> CreateAddress(Address address)
        {
            return _iOrderRepository.CreateAddress(address);
        }

        public Task<HttpStatusCode> DeleteOrderAsync(int id)
        {
            return _iOrderRepository.DeleteOrderAsync(id);
        }

        public Task<Address> GetAddressByIDAsync(int id)
        {
            return _iOrderRepository.GetAddressByIDAsync(id);
        }

        public Task<Order> GetOrderByIDAsync(int id)
        {
            return _iOrderRepository.GetOrderByIDAsync(id);
        }

        public Task<List<OrderItem>> GetOrderItemsByOrderIDAsync(int id)
        {
            return _iOrderRepository.GetOrderItemsByOrderIDAsync(id);
        }

        public Task<List<Order>> GetRecentOrdersAsync(int n, int? orderId)
        {
            return _iOrderRepository.GetRecentOrdersAsync(n, orderId);
        }

        public Task<List<Order>> GetRecentOrdersAsync(int n, string userID)
        {
            return _iOrderRepository.GetRecentOrdersAsync(n, userID);
        }

        public Task<HttpStatusCode> UpdateOrderAsync(Order order)
        {
            return _iOrderRepository.UpdateOrderAsync(order);
        }
        public Task<List<Order>> GetRecentOrdersByUserAsync(int n, string userId)
        {
            return _iOrderRepository.GetRecentOrdersByUserAsync(n, userId);
        }
    }
}
