﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace EComWebApp.Models
{
    public interface ICartService
    {
        Task<HttpStatusCode> CreateCart(Cart Cart);

        Task<HttpStatusCode> AddProductToCart(string email, Product product);

        Task<Cart> GetUserCartByEmail(string email);

        Task<HttpStatusCode> UpdateCart(string email, CartItem cartItem);

        Task<HttpStatusCode> DeleteProductFromCart(CartItem cartItem);

        Task<HttpStatusCode> ClearOutCart(List<CartItem> cartItems);
    }
}
