﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;

namespace EComWebApp.Models
{
    public class Payment
    {
        public IConfiguration Configuration { get; set; }

        public Payment(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public string RunPayment(decimal amount, Order datOrder, ApplicationUser user)
        {
            return "invalid";
        }
    }
}