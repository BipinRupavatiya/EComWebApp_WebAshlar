﻿using Microsoft.EntityFrameworkCore;
using EComWebApp.Data;

namespace EComWebApp.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new DBContext(
                    serviceProvider.GetRequiredService<DbContextOptions<DBContext>>()))
            {
                if (context.Products.Any()) return;
                
            }
        }
    }
}