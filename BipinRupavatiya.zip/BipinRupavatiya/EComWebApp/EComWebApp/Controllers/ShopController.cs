﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using EComWebApp.Models;
using EComWebApp.Models.ViewModel;
using EComWebApp.Filter;

namespace EComWebApp.Controllers
{
	[Authorize]
	[TypeFilter(typeof(ExceptionFilter))]
	public class ShopController : Controller
    {
        private readonly IProductService _productService;
        private readonly ICartService _cartService;
        private readonly IOrderService _orderService;
        private readonly IConfiguration Configuration;
        private UserManager<ApplicationUser> _userManager;
        public ShopController(IProductService productService, IConfiguration configuration,
            ICartService cartService, IOrderService orderService, UserManager<ApplicationUser> userManager)
        {
            _productService = productService;
            _cartService = cartService;
            _orderService = orderService;
            _userManager = userManager;
            Configuration = configuration;
        }

        public IActionResult Index(string searchString)
        {
            var products = _productService.GetProducts().Result.AsQueryable();
            if (!String.IsNullOrEmpty(searchString))
            {
                products = products.Where(s => s.Name.ToLower().Contains(searchString.ToLower()));
            }
            ProductListingVM productListVM = new ProductListingVM
            {
                Products = products.ToList()
            };
            return View(productListVM);
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var foundProduct = await _productService.GetProductById(id);

            if (foundProduct == null) return NotFound();

            return View(foundProduct);
        }
      
        [HttpPost]
        public async Task<IActionResult> Add(int? id)
        {
            var user = await _userManager.FindByEmailAsync(User.Identity.Name);
            Product product = _productService.GetProductById(id).Result;
            Cart cart = await _cartService.GetUserCartByEmail(user.Email);
            if (cart == null)
            {
                Cart datBasket = new Cart
                {
                    CustomerEmail = user.Email
                };
                await _cartService.CreateCart(datBasket);
            }
            await _cartService.AddProductToCart(user.Email, product);
            return RedirectToAction(nameof(MyBasket));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update()
        {
            try
            {
                CartItem cart = new CartItem
                {
                    ID = Convert.ToInt32(Request.Form["cartItems.ID"]),
                    ProductID = Convert.ToInt32(Request.Form["cartItems.ProductID"]),
                    ProductName = Request.Form["cartItems.ProductName"].ToString(),
                    CustomerEmail = Request.Form["cartItems.CustomerEmail"].ToString(),
                    Quantity = Convert.ToInt32(Request.Form["cartItems.Quantity"]),
                    ImgUrl = Request.Form["cartItems.ImgUrl"].ToString(),
                    UnitPrice = Convert.ToDecimal(Request.Form["cartItems.UnitPrice"]),
                };
                if (cart.Quantity == 0)
                {
                    await _cartService.DeleteProductFromCart(cart);
                }
                else
                {
                    await _cartService.UpdateCart(User.Identity.Name, cart);
                }
            }
            catch
            {
                throw;
            }
            return RedirectToAction(nameof(MyBasket));
        }
      
        [HttpPost]
        public async Task<IActionResult> Delete()
        {
            CartItem cart = new CartItem
            {
                ID = Convert.ToInt32(Request.Form["cartItems.ID"]),
                ProductID = Convert.ToInt32(Request.Form["cartItems.ProductID"]),
                ProductName = Request.Form["cartItems.ProductName"].ToString(),
                CustomerEmail = Request.Form["cartItems.CustomerEmail"].ToString(),
                Quantity = Convert.ToInt32(Request.Form["cartItems.Quantity"]),
                ImgUrl = Request.Form["cartItems.ImgUrl"].ToString(),
                UnitPrice = Convert.ToDecimal(Request.Form["cartItems.UnitPrice"]),
            };
            await _cartService.DeleteProductFromCart(cart);
            return RedirectToAction(nameof(MyBasket));
        }

        [Authorize]
        public async Task<IActionResult> MyBasket()
        {
            var user = await _userManager.FindByEmailAsync(User.Identity.Name);
            Cart datCart = _cartService.GetUserCartByEmail(user.Email).Result;

            return View(datCart);
        }

        [HttpGet]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            var user = await _userManager.FindByEmailAsync(User.Identity.Name);
            Order order = await _orderService.GetOrderByIDAsync(id);
            if (order.UserID != user.Id)
                return RedirectToAction("RecentOrders", "Shop");

            await _orderService.DeleteOrderAsync(id);
            return RedirectToAction("RecentOrders", "Shop");
        }
        public async Task<IActionResult> RecentOrders()
        {
            var user = await _userManager.FindByEmailAsync(User.Identity.Name);
            List<Order> recentOrders = await _orderService.GetRecentOrdersByUserAsync(20, user.Id);
            OrderListViewModel datOrderListVM = new OrderListViewModel
            {
                Orders = recentOrders,
            };

            return View(datOrderListVM);
        }
        public async Task<IActionResult> OrderDetails(int id)
        {
            Order datOrder = await _orderService.GetOrderByIDAsync(id);
            datOrder.Address = await _orderService.GetAddressByIDAsync(datOrder.AddressID);
            return View(datOrder);
        }
        [HttpPost]
        public async Task<IActionResult> DeleteOrderConfirmed(int id)
        {
            await _orderService.DeleteOrderAsync(id);
            return RedirectToAction(nameof(RecentOrders));
        }
    }
}