﻿using EComWebApp.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EComWebApp.Controllers
{
    [Authorize]
	[TypeFilter(typeof(ExceptionFilter))]
	public class MemberController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}