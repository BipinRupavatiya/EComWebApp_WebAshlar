﻿using EComWebApp.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EComWebApp.Controllers
{
	[TypeFilter(typeof(ExceptionFilter))]
	public class HomeController : Controller
    {
        public HomeController()
        {
        }

        public IActionResult Index()
        {
            return View();
        }
        [Authorize(Policy = "IsMember")]
        public IActionResult Doge()
        {
            return View();
        }
    }
}