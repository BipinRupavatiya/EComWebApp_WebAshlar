﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using EComWebApp.Models;

namespace EComWebApp.Controllers.Components
{
    public class ShoppingCart : ViewComponent
    {
        private readonly ICartService _cartService;
        private UserManager<ApplicationUser> _userManager;
        public ShoppingCart(IProductService productService, IConfiguration configuration, ICartService cartService,
            UserManager<ApplicationUser> userManager)
        {
            _cartService = cartService;
            _userManager = userManager;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            Cart dataCart;
            var user = await _userManager.FindByEmailAsync(User.Identity.Name);
            dataCart = _cartService.GetUserCartByEmail(user.Email).Result;
            if (dataCart == null)
            {
                dataCart = new Cart();
            }
            return View(dataCart);
        }
    }
}