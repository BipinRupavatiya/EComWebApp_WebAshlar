﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EComWebApp.Models;
using EComWebApp.Models.ViewModel;
using EComWebApp.Filter;

namespace EComWebApp.Controllers
{
    [Authorize(Policy = "AdminOnly")]
	[TypeFilter(typeof(ExceptionFilter))]
	public class AdminController : Controller
    {
        private readonly IConfiguration Configuration;
        private readonly IProductService _productService;
        private readonly IOrderService _orderService;

        public AdminController(IProductService productService, IConfiguration configuration, IOrderService orderService)
        {
            _productService = productService;
            _orderService = orderService;
            Configuration = configuration;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpGet, ActionName("ViewAll")]
        public async Task<IActionResult> GetAllProducts()
        {
            List<Product> products = await _productService.GetProducts();
            ProductListingVM productListVM = new ProductListingVM
            {
                Products = products
            };
            return View(productListVM);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create([Bind("ID, Name, SKU, Price, Description, ImgUrl")] Product product)
        {
            if (ModelState.IsValid)
            {
                await _productService.CreateProduct(product);
                return RedirectToAction("ViewAll");
            }
            return View(product);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            var product = await _productService.GetProductById(id);
            if (product == null)
            {
                return RedirectToAction("ViewAll");
            }
            return View(product);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var foundProduct = await _productService.GetProductById(id);

            if (foundProduct == null) return NotFound();

            return View(foundProduct);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID, Name, SKU, Price, Description, ImgUrl")] Product product)
        {
            if (id != product.ID)
            {
                return RedirectToAction("ViewAll");
            }
            if (ModelState.IsValid)
            {
                try
                {
                    await _productService.UpdateProduct(id, product);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExistsAsync(product.ID).Result)
                    {
                        return RedirectToAction("ViewAll");
                    }
                    throw;
                }
                return RedirectToAction("ViewAll");
            }
            return View(product);
        }
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ViewAll");
            }

            var product = await _productService.GetProductById(id);
            if (product == null)
            {
                return RedirectToAction("ViewAll");
            }
            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmAsync(int id)
        {
            await _productService.DeleteProduct(id);
            return RedirectToAction("ViewAll");
        }
        
        public async Task<IActionResult> RecentOrders(int? SearchString)
        {
            List<Order> recentOrders = await _orderService.GetRecentOrdersAsync(20, SearchString);
            OrderListViewModel datOrderListVM = new OrderListViewModel
            {
                Orders = recentOrders,
            };

            return View(datOrderListVM);
        }

        public async Task<IActionResult> OrderDetails(int id)
        {
            Order datOrder = await _orderService.GetOrderByIDAsync(id);
            datOrder.Address = await _orderService.GetAddressByIDAsync(datOrder.AddressID);
            return View(datOrder);
        }

        public async Task<IActionResult> DeleteOrder(int id)
        {
            Order datOrder = await _orderService.GetOrderByIDAsync(id);
            datOrder.Address = await _orderService.GetAddressByIDAsync(datOrder.AddressID);
            return View(datOrder);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteOrderConfirmed(int id)
        {
            await _orderService.DeleteOrderAsync(id);
            return RedirectToAction(nameof(RecentOrders));
        }
       
        private async Task<bool> ProductExistsAsync(int id)
        {
            var products = await _productService.GetProducts();
            return products.Any(p => p.ID == id);
        }
    }
}