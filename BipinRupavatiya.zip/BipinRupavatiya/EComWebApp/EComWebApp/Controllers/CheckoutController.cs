﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using EComWebApp.Models;
using EComWebApp.Models.ViewModel;
using EComWebApp.Filter;

namespace EComWebApp.Controllers
{
	[Authorize]
	[TypeFilter(typeof(ExceptionFilter))]
	public class CheckoutController : Controller
	{
		private readonly IProductService _productService;
		private readonly ICartService _cartService;
		private readonly IOrderService _orderService;
		private readonly IConfiguration Configuration;
		private UserManager<ApplicationUser> _userManager;
		public CheckoutController(IProductService productService, IConfiguration configuration,
			ICartService cartService, IOrderService orderService,
			UserManager<ApplicationUser> userManager)
		{
			_productService = productService;
			_cartService = cartService;
			_orderService = orderService;
			_userManager = userManager;
			Configuration = configuration;
		}
		public async Task<IActionResult> Index(string discountCoupon)
		{
			var user = await _userManager.FindByEmailAsync(User.Identity.Name);
			Cart dataCart = _cartService.GetUserCartByEmail(user.Email).Result;
			if (dataCart == null || dataCart.cartItems.Count == 0)
			{
				return RedirectToAction("MyBasket", "Shop");
			}
			CheckoutViewModel datCheckoutVM = new CheckoutViewModel
			{
				Cart = dataCart,
			};
			return View(datCheckoutVM);
		}
		[HttpPost]
		public async Task<IActionResult> AddAddress(CheckoutViewModel cvm)
		{
			if (cvm == null || cvm.Address == null)
			{
				return RedirectToAction(nameof(Index));
			}
			var user = await _userManager.FindByEmailAsync(User.Identity.Name);
			Cart dataCart = _cartService.GetUserCartByEmail(user.Email).Result;
			cvm.Cart = dataCart; ;
			return View("Shipping", cvm);
		}
		public async Task<IActionResult> Shipping(CheckoutViewModel cvm)
		{
			var user = await _userManager.FindByEmailAsync(User.Identity.Name);
			Cart dataCart = _cartService.GetUserCartByEmail(user.Email).Result;
			cvm.Cart = dataCart;
			if (ModelState.IsValid)
			{
				return View(cvm);
			}
			return RedirectToAction(nameof(Index));
		}

		[HttpPost]
		public async Task<IActionResult> Confirm(CheckoutViewModel cvm)
		{
			var user = await _userManager.FindByEmailAsync(User.Identity.Name);
			Cart dataCart = _cartService.GetUserCartByEmail(user.Email).Result;

			if (dataCart.cartItems.Count == 0)
				return RedirectToAction(nameof(Index));

			cvm.Cart = dataCart;
			cvm.DiscountName = string.Empty;

			ModelState.Remove("Cart");
			ModelState.Remove("DiscountName");

			if (!ModelState.IsValid)
				return RedirectToAction(nameof(Shipping));
			await _orderService.CreateAddress(cvm.Address);
			Order datOrder = new Order
			{
				UserID = user.Id,
				UserName = user.FirstName + " " + user.LastName,
				AddressID = cvm.Address.ID,
				Address = cvm.Address,
				OrderDate = DateTime.Now,
				Shipping = cvm.Shipping,
				DiscountName = cvm.DiscountName,
				DiscountPercent = cvm.DiscountPercent,
				DiscountAmt = cvm.DiscountAmt,
				TotalItemQty = cvm.TotalItemQty,
				Subtotal = cvm.Subtotal,
				Total = cvm.Total,
			};
			await _orderService.AddOrderAsync(datOrder);
			List<OrderItem> demOrderItems = new List<OrderItem>();
			foreach (var item in dataCart.cartItems)
			{
				OrderItem tempOrderItem = new OrderItem
				{
					ProductID = item.ProductID,
					OrderID = datOrder.ID,
					UserID = user.Id,
					ProductName = item.ProductName,
					Quantity = item.Quantity,
					ImgUrl = item.ImgUrl,
					UnitPrice = item.UnitPrice
				};
				await _orderService.AddOrderItemToOrderAsync(tempOrderItem);
				demOrderItems.Add(tempOrderItem);
			}
			datOrder.OrderItems = demOrderItems;
			string htmlMessage = "Thank you for shopping with us!  You ordered: </br>";
			foreach (var item in datOrder.OrderItems)
			{
				htmlMessage += $"Item: {item.ProductName}, Quantity: {item.Quantity}</br>";
			};
			await _cartService.ClearOutCart(cvm.Cart.cartItems);
			return View("Confirmed", datOrder);
		}
		public IActionResult Confirmed(Order order)
		{
			return View(order);
		}
	}
}